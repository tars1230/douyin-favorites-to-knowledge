"""Deterministic identifiers for source, item, and processing ownership."""

from __future__ import annotations

import re

from .artifacts import canonical_json, sha256_bytes


_KEY_RE = re.compile(r"^(src1|item1|wk1):[0-9a-f]{64}$")


def require_identifier(name: str, value: str, *, allow_empty: bool = False) -> str:
    """Validate an opaque identifier without silently normalizing it."""

    if not isinstance(value, str):
        raise TypeError(f"{name} must be str")
    if value != value.strip():
        raise ValueError(f"{name} must not have surrounding whitespace")
    if not value and not allow_empty:
        raise ValueError(f"{name} must not be empty")
    if any(ord(character) < 32 or ord(character) == 127 for character in value):
        raise ValueError(f"{name} must not contain control characters")
    return value


def make_source_id(
    *, platform: str, account_id: str, kind: str, stable_id: str
) -> str:
    """Return a stable source identity key.

    Input strings are opaque and hashed exactly as supplied. Source adapters own
    platform-specific normalization before calling this function.
    """

    payload = {
        "account_id": require_identifier("account_id", account_id),
        "kind": require_identifier("kind", kind),
        "platform": require_identifier("platform", platform),
        "stable_id": require_identifier("stable_id", stable_id),
    }
    return "src1:" + sha256_bytes(canonical_json(payload))


def make_source_item_key(*, source_id: str, external_id: str) -> str:
    """Return the stable identity of an item independent of processing version."""

    require_namespaced_key("source_id", source_id, "src1")
    payload = {
        "external_id": require_identifier("external_id", external_id),
        "source_id": source_id,
    }
    return "item1:" + sha256_bytes(canonical_json(payload))


def make_work_key(
    *, source_id: str, external_id: str, processing_version: str
) -> str:
    """Return the idempotency key for one item at one processing contract version."""

    require_namespaced_key("source_id", source_id, "src1")
    payload = {
        "external_id": require_identifier("external_id", external_id),
        "processing_version": require_identifier(
            "processing_version", processing_version
        ),
        "source_id": source_id,
    }
    return "wk1:" + sha256_bytes(canonical_json(payload))


def require_namespaced_key(name: str, value: str, prefix: str) -> str:
    """Validate a core key and its expected namespace."""

    require_identifier(name, value)
    if prefix not in {"src1", "item1", "wk1"}:
        raise ValueError(f"unknown key prefix: {prefix}")
    if not _KEY_RE.fullmatch(value) or not value.startswith(prefix + ":"):
        raise ValueError(f"{name} must be a valid {prefix} key")
    return value
