"""Immutable domain contracts shared by Douyin knowledge products."""

from __future__ import annotations

import re
from dataclasses import dataclass
from datetime import datetime
from enum import Enum
from pathlib import PurePosixPath
from typing import Any

from .ids import (
    make_source_id,
    make_source_item_key,
    require_identifier,
    require_namespaced_key,
)


SCHEMA_VERSION = 1
_SHA256_RE = re.compile(r"^[0-9a-f]{64}$")
_ERROR_CODE_RE = re.compile(r"^[a-z][a-z0-9_.-]{0,63}$")
_SLUG_RE = re.compile(r"^[a-z][a-z0-9_-]{0,63}$")
_SENSITIVE_ATTRIBUTE_RE = re.compile(
    r"(?i)(^|[._-])(api[_-]?key|token|secret|password)($|[._-])"
)
Scalar = str | int | bool | None


def _require_sha256(name: str, value: str) -> str:
    if not isinstance(value, str) or not _SHA256_RE.fullmatch(value):
        raise ValueError(f"{name} must be a lowercase SHA-256 digest")
    return value


def _parse_timestamp(name: str, value: str) -> datetime:
    require_identifier(name, value)
    try:
        parsed = datetime.fromisoformat(value.replace("Z", "+00:00"))
    except ValueError as error:
        raise ValueError(f"{name} must be an ISO-8601 timestamp") from error
    if parsed.tzinfo is None or parsed.utcoffset() is None:
        raise ValueError(f"{name} must include a UTC offset")
    return parsed


def _require_nonempty_text(name: str, value: str) -> str:
    if not isinstance(value, str):
        raise TypeError(f"{name} must be str")
    if not value.strip():
        raise ValueError(f"{name} must not be blank")
    return value


def _require_tuple(name: str, value: Any) -> tuple[Any, ...]:
    if not isinstance(value, tuple):
        raise TypeError(f"{name} must be tuple")
    return value


def _require_unique_strings(
    name: str, value: tuple[str, ...], *, allow_empty_tuple: bool = True
) -> tuple[str, ...]:
    _require_tuple(name, value)
    if not value and not allow_empty_tuple:
        raise ValueError(f"{name} must not be empty")
    for item in value:
        require_identifier(f"{name} item", item)
    if len(set(value)) != len(value):
        raise ValueError(f"{name} must not contain duplicates")
    return value


def _require_relative_path(value: str) -> str:
    require_identifier("relative_path", value)
    if "\\" in value:
        raise ValueError("relative_path must use POSIX separators")
    if any(part in {"", ".", ".."} for part in value.split("/")):
        raise ValueError("relative_path must use normalized path segments")
    path = PurePosixPath(value)
    if path.is_absolute() or ".." in path.parts:
        raise ValueError("relative_path must stay below its evidence root")
    return value


class KnowledgeStatus(str, Enum):
    METADATA_ONLY = "metadata_only"
    READY = "ready"
    PARTIAL = "partial"
    SUPERSEDED = "superseded"
    TRASHED = "trashed"


class TaskState(str, Enum):
    PROCESSING = "processing"
    RETRYING = "retrying"
    ACTION_REQUIRED = "action_required"
    PAUSED = "paused"
    PARTIAL = "partial"
    COMPLETED = "completed"


@dataclass(frozen=True, slots=True)
class SourceIdentity:
    platform: str
    account_id: str
    kind: str
    stable_id: str
    profile_id: str = ""

    def __post_init__(self) -> None:
        if not isinstance(self.platform, str) or not _SLUG_RE.fullmatch(self.platform):
            raise ValueError("platform must be a lowercase slug")
        require_identifier("account_id", self.account_id)
        if not isinstance(self.kind, str) or not _SLUG_RE.fullmatch(self.kind):
            raise ValueError("kind must be a lowercase slug")
        require_identifier("stable_id", self.stable_id)
        require_identifier("profile_id", self.profile_id, allow_empty=True)

    @property
    def source_id(self) -> str:
        return make_source_id(
            platform=self.platform,
            account_id=self.account_id,
            kind=self.kind,
            stable_id=self.stable_id,
        )

    def to_dict(self) -> dict[str, Any]:
        return {
            "schema_version": SCHEMA_VERSION,
            "source_id": self.source_id,
            "platform": self.platform,
            "account_id": self.account_id,
            "profile_id": self.profile_id,
            "kind": self.kind,
            "stable_id": self.stable_id,
        }


@dataclass(frozen=True, slots=True)
class SourceItem:
    source_id: str
    external_id: str
    author: str
    created_at: str
    text: str
    media_refs: tuple[str, ...]
    raw_sha256: str

    def __post_init__(self) -> None:
        require_namespaced_key("source_id", self.source_id, "src1")
        require_identifier("external_id", self.external_id)
        if not isinstance(self.author, str):
            raise TypeError("author must be str")
        _parse_timestamp("created_at", self.created_at)
        if not isinstance(self.text, str):
            raise TypeError("text must be str")
        _require_unique_strings("media_refs", self.media_refs)
        _require_sha256("raw_sha256", self.raw_sha256)

    @property
    def source_item_key(self) -> str:
        return make_source_item_key(
            source_id=self.source_id, external_id=self.external_id
        )

    def to_dict(self) -> dict[str, Any]:
        return {
            "schema_version": SCHEMA_VERSION,
            "source_item_key": self.source_item_key,
            "source_id": self.source_id,
            "external_id": self.external_id,
            "author": self.author,
            "created_at": self.created_at,
            "text": self.text,
            "media_refs": list(self.media_refs),
            "raw_sha256": self.raw_sha256,
        }


@dataclass(frozen=True, slots=True)
class EvidenceBlob:
    sha256: str
    media_type: str
    size_bytes: int
    relative_path: str
    acquired_at: str

    def __post_init__(self) -> None:
        _require_sha256("sha256", self.sha256)
        require_identifier("media_type", self.media_type)
        if not isinstance(self.size_bytes, int) or isinstance(self.size_bytes, bool):
            raise TypeError("size_bytes must be int")
        if self.size_bytes < 0:
            raise ValueError("size_bytes must be non-negative")
        _require_relative_path(self.relative_path)
        _parse_timestamp("acquired_at", self.acquired_at)

    def to_dict(self) -> dict[str, Any]:
        return {
            "schema_version": SCHEMA_VERSION,
            "sha256": self.sha256,
            "media_type": self.media_type,
            "size_bytes": self.size_bytes,
            "relative_path": self.relative_path,
            "acquired_at": self.acquired_at,
        }


@dataclass(frozen=True, slots=True)
class Citation:
    evidence_sha256: str
    excerpt: str
    time_start_ms: int | None = None
    time_end_ms: int | None = None
    char_start: int | None = None
    char_end: int | None = None

    def __post_init__(self) -> None:
        _require_sha256("evidence_sha256", self.evidence_sha256)
        _require_nonempty_text("excerpt", self.excerpt)
        time_range = self._validate_range(
            "time", self.time_start_ms, self.time_end_ms
        )
        char_range = self._validate_range("char", self.char_start, self.char_end)
        if time_range and char_range:
            raise ValueError("citation cannot mix time and character ranges")

    @staticmethod
    def _validate_range(name: str, start: int | None, end: int | None) -> bool:
        if (start is None) != (end is None):
            raise ValueError(f"{name} range requires both start and end")
        if start is None:
            return False
        if (
            not isinstance(start, int)
            or isinstance(start, bool)
            or not isinstance(end, int)
            or isinstance(end, bool)
        ):
            raise TypeError(f"{name} range values must be int")
        if start < 0 or end <= start:
            raise ValueError(f"{name} range must be a non-empty half-open range")
        return True

    def to_dict(self) -> dict[str, Any]:
        return {
            "schema_version": SCHEMA_VERSION,
            "evidence_sha256": self.evidence_sha256,
            "excerpt": self.excerpt,
            "time_start_ms": self.time_start_ms,
            "time_end_ms": self.time_end_ms,
            "char_start": self.char_start,
            "char_end": self.char_end,
        }


@dataclass(frozen=True, slots=True)
class KnowledgeItem:
    stable_id: str
    title: str
    body: str
    tags: tuple[str, ...]
    status: KnowledgeStatus
    source_item_key: str
    version: int
    citations: tuple[Citation, ...] = ()

    def __post_init__(self) -> None:
        require_identifier("stable_id", self.stable_id)
        _require_nonempty_text("title", self.title)
        if not isinstance(self.body, str):
            raise TypeError("body must be str")
        _require_unique_strings("tags", self.tags)
        if not isinstance(self.status, KnowledgeStatus):
            raise TypeError("status must be KnowledgeStatus")
        require_namespaced_key(
            "source_item_key", self.source_item_key, "item1"
        )
        if not isinstance(self.version, int) or isinstance(self.version, bool):
            raise TypeError("version must be int")
        if self.version < 1:
            raise ValueError("version must be positive")
        _require_tuple("citations", self.citations)
        if not all(isinstance(item, Citation) for item in self.citations):
            raise TypeError("citations must contain Citation values")
        if self.status in {KnowledgeStatus.READY, KnowledgeStatus.PARTIAL}:
            if not self.body.strip():
                raise ValueError("ready or partial knowledge requires a non-empty body")
            if not self.citations:
                raise ValueError("ready or partial knowledge requires evidence citations")

    def to_dict(self) -> dict[str, Any]:
        return {
            "schema_version": SCHEMA_VERSION,
            "stable_id": self.stable_id,
            "title": self.title,
            "body": self.body,
            "tags": list(self.tags),
            "status": self.status.value,
            "source_item_key": self.source_item_key,
            "version": self.version,
            "citations": [citation.to_dict() for citation in self.citations],
        }


@dataclass(frozen=True, slots=True)
class TaskScope:
    source_ids: tuple[str, ...]
    external_ids: tuple[str, ...] = ()
    started_at: str | None = None
    ended_at: str | None = None
    attributes: tuple[tuple[str, Scalar], ...] = ()

    def __post_init__(self) -> None:
        _require_unique_strings("source_ids", self.source_ids, allow_empty_tuple=False)
        for source_id in self.source_ids:
            require_namespaced_key("source_ids item", source_id, "src1")
        _require_unique_strings("external_ids", self.external_ids)
        start = (
            _parse_timestamp("started_at", self.started_at)
            if self.started_at is not None
            else None
        )
        end = (
            _parse_timestamp("ended_at", self.ended_at)
            if self.ended_at is not None
            else None
        )
        if start is not None and end is not None and end < start:
            raise ValueError("ended_at must not precede started_at")
        _require_tuple("attributes", self.attributes)
        keys: list[str] = []
        for item in self.attributes:
            if not isinstance(item, tuple) or len(item) != 2:
                raise TypeError("attributes must contain (key, scalar) tuples")
            key, value = item
            require_identifier("attribute key", key)
            if _SENSITIVE_ATTRIBUTE_RE.search(key):
                raise ValueError("attributes must not contain secret-bearing keys")
            if not isinstance(value, (str, int, bool, type(None))):
                raise TypeError("attribute values must be JSON scalar values")
            keys.append(key)
        if len(set(keys)) != len(keys):
            raise ValueError("attribute keys must be unique")

    def to_dict(self) -> dict[str, Any]:
        return {
            "schema_version": SCHEMA_VERSION,
            "source_ids": list(self.source_ids),
            "external_ids": list(self.external_ids),
            "started_at": self.started_at,
            "ended_at": self.ended_at,
            "attributes": dict(sorted(self.attributes)),
        }


@dataclass(frozen=True, slots=True)
class TaskCounts:
    total: int
    succeeded: int = 0
    failed: int = 0
    skipped: int = 0
    unchanged: int = 0

    def __post_init__(self) -> None:
        for name in ("total", "succeeded", "failed", "skipped", "unchanged"):
            value = getattr(self, name)
            if not isinstance(value, int) or isinstance(value, bool):
                raise TypeError(f"{name} must be int")
            if value < 0:
                raise ValueError(f"{name} must be non-negative")
        if self.terminal > self.total:
            raise ValueError("terminal counts must not exceed total")

    @property
    def terminal(self) -> int:
        return self.succeeded + self.failed + self.skipped + self.unchanged

    @property
    def pending(self) -> int:
        return self.total - self.terminal

    def to_dict(self) -> dict[str, int]:
        return {
            "total": self.total,
            "succeeded": self.succeeded,
            "failed": self.failed,
            "skipped": self.skipped,
            "unchanged": self.unchanged,
            "pending": self.pending,
        }


@dataclass(frozen=True, slots=True)
class TaskError:
    code: str
    message: str
    retryable: bool
    external_id: str | None = None

    def __post_init__(self) -> None:
        if not isinstance(self.code, str) or not _ERROR_CODE_RE.fullmatch(self.code):
            raise ValueError("code must be a stable lowercase error code")
        _require_nonempty_text("message", self.message)
        if not isinstance(self.retryable, bool):
            raise TypeError("retryable must be bool")
        if self.external_id is not None:
            require_identifier("external_id", self.external_id)

    def to_dict(self) -> dict[str, Any]:
        return {
            "code": self.code,
            "message": self.message,
            "retryable": self.retryable,
            "external_id": self.external_id,
        }


@dataclass(frozen=True, slots=True)
class TaskReceipt:
    task_id: str
    scope: TaskScope
    counts: TaskCounts
    state: TaskState
    errors: tuple[TaskError, ...]
    started_at: str
    finished_at: str | None = None

    def __post_init__(self) -> None:
        require_identifier("task_id", self.task_id)
        if not isinstance(self.scope, TaskScope):
            raise TypeError("scope must be TaskScope")
        if not isinstance(self.counts, TaskCounts):
            raise TypeError("counts must be TaskCounts")
        if not isinstance(self.state, TaskState):
            raise TypeError("state must be TaskState")
        _require_tuple("errors", self.errors)
        if not all(isinstance(item, TaskError) for item in self.errors):
            raise TypeError("errors must contain TaskError values")
        start = _parse_timestamp("started_at", self.started_at)
        end = (
            _parse_timestamp("finished_at", self.finished_at)
            if self.finished_at is not None
            else None
        )
        is_terminal = self.state in {TaskState.PARTIAL, TaskState.COMPLETED}
        if is_terminal != (end is not None):
            raise ValueError("only terminal task states require finished_at")
        if end is not None and end < start:
            raise ValueError("finished_at must not precede started_at")
        if self.counts.failed and not self.errors:
            raise ValueError("failed item counts require at least one TaskError")
        if self.state is TaskState.COMPLETED and (
            self.counts.failed or self.counts.pending or self.errors
        ):
            raise ValueError("completed tasks cannot have failed, pending, or error state")
        if self.state is TaskState.PARTIAL and not (
            self.counts.succeeded
            or self.counts.skipped
            or self.counts.unchanged
        ):
            raise ValueError("partial tasks require at least one completed item")

    def to_dict(self) -> dict[str, Any]:
        return {
            "schema_version": SCHEMA_VERSION,
            "task_id": self.task_id,
            "scope": self.scope.to_dict(),
            "counts": self.counts.to_dict(),
            "state": self.state.value,
            "errors": [error.to_dict() for error in self.errors],
            "started_at": self.started_at,
            "finished_at": self.finished_at,
        }
