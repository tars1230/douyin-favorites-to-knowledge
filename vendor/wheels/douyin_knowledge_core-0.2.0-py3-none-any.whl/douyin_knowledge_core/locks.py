"""Cross-process locking for shared browser authorization profiles."""

from __future__ import annotations

import errno
import math
import os
import platform
import threading
import time
from contextlib import contextmanager
from pathlib import Path
from typing import Iterator

from .artifacts import sha256_bytes

try:
    import fcntl as _fcntl
except ImportError:  # pragma: no cover - exercised through a patched capability test
    _fcntl = None


class InterprocessLockError(RuntimeError):
    """Base class for deterministic lock failures."""


class LockBusyError(InterprocessLockError, TimeoutError):
    """Raised when another process or thread owns the requested lock."""


class LockReentryError(InterprocessLockError):
    """Raised instead of treating a same-thread nested lock as reentrant."""


class LockUnsupportedError(InterprocessLockError):
    """Raised when the host has no supported advisory-lock implementation."""


_thread_state = threading.local()


def canonical_profile_path(path: str | os.PathLike[str]) -> Path:
    """Return the absolute, symlink-resolved identity path for a profile."""

    if isinstance(path, bytes):
        raise TypeError("profile path must be str or os.PathLike[str]")
    try:
        resolved = Path(path).expanduser().resolve(strict=False)
    except (OSError, RuntimeError) as error:
        raise ValueError("profile path cannot be resolved") from error
    current = Path(resolved.anchor)
    parts = resolved.parts[1:]
    for index, part in enumerate(parts):
        requested = current / part
        try:
            requested_stat = requested.stat()
        except OSError:
            return current.joinpath(*parts[index:])
        actual_name = part
        try:
            with os.scandir(current) as entries:
                for entry in entries:
                    if entry.name == part:
                        actual_name = entry.name
                        break
                    try:
                        if os.path.samestat(
                            requested_stat, entry.stat(follow_symlinks=True)
                        ):
                            actual_name = entry.name
                            break
                    except OSError:
                        continue
        except OSError:
            return current.joinpath(*parts[index:])
        current /= actual_name
    return current


def profile_lock_key(path: str | os.PathLike[str]) -> str:
    """Return a stable lock identity for all aliases of one profile path."""

    normalized = canonical_profile_path(path)
    if not normalized.is_dir():
        raise ValueError("profile directory must exist before locking")
    digest = sha256_bytes(os.fsencode(normalized))
    return f"plk1:{digest}"


def default_profile_lock_root() -> Path:
    """Return a neutral per-user runtime directory for profile lock files."""

    home = Path.home()
    system = platform.system()
    if system == "Darwin":
        root = home / "Library" / "Caches"
    elif system == "Windows":
        root = Path(os.environ.get("LOCALAPPDATA", home / "AppData" / "Local"))
    else:
        runtime_root = os.environ.get("XDG_RUNTIME_DIR")
        if runtime_root:
            return Path(runtime_root).expanduser() / "douyin-knowledge-core" / "locks"
        root = Path(os.environ.get("XDG_CACHE_HOME", home / ".cache"))
    return root / "douyin-knowledge-core" / "locks"


def profile_lock_path(
    profile_path: str | os.PathLike[str],
    *,
    lock_root: str | os.PathLike[str] | None = None,
) -> Path:
    """Return the non-sensitive lock-file path for a profile."""

    digest = profile_lock_key(profile_path).split(":", 1)[1]
    return _profile_lock_path_from_digest(digest, lock_root=lock_root)


def _profile_lock_path_from_digest(
    digest: str, *, lock_root: str | os.PathLike[str] | None
) -> Path:
    root = (
        Path(lock_root).expanduser()
        if lock_root is not None
        else default_profile_lock_root()
    )
    if not root.is_absolute():
        raise ValueError("lock_root must be absolute")
    root = canonical_profile_path(root)
    return root / f"profile-{digest}.lock"


def _held_keys() -> set[str]:
    held = getattr(_thread_state, "held_keys", None)
    if held is None:
        held = set()
        _thread_state.held_keys = held
    return held


def _validate_wait_options(
    *, blocking: bool, timeout: float | None, poll_interval: float
) -> None:
    if not isinstance(blocking, bool):
        raise TypeError("blocking must be bool")
    if timeout is not None:
        if isinstance(timeout, bool) or not isinstance(timeout, (int, float)):
            raise TypeError("timeout must be a number or None")
        if timeout < 0:
            raise ValueError("timeout must be non-negative")
        try:
            finite_timeout = math.isfinite(timeout)
        except OverflowError:
            finite_timeout = False
        if not finite_timeout:
            raise ValueError("timeout must be finite")
        if not blocking and timeout != 0:
            raise ValueError("non-blocking locks only accept timeout=None or 0")
    if isinstance(poll_interval, bool) or not isinstance(poll_interval, (int, float)):
        raise TypeError("poll_interval must be a number")
    if poll_interval <= 0:
        raise ValueError("poll_interval must be positive")
    try:
        finite_poll_interval = math.isfinite(poll_interval)
    except OverflowError:
        finite_poll_interval = False
    if not finite_poll_interval:
        raise ValueError("poll_interval must be finite")


@contextmanager
def _exclusive_lock(
    lock_path: Path,
    *,
    identity: str,
    blocking: bool,
    timeout: float | None,
    poll_interval: float,
) -> Iterator[None]:
    _validate_wait_options(
        blocking=blocking, timeout=timeout, poll_interval=poll_interval
    )
    if _fcntl is None:
        raise LockUnsupportedError(
            "reliable cross-process advisory locks are unavailable on this platform"
        )

    held = _held_keys()
    if identity in held:
        raise LockReentryError("the current thread already owns this lock")

    lock_root_existed = lock_path.parent.exists()
    lock_path.parent.mkdir(parents=True, exist_ok=True, mode=0o700)
    if not lock_root_existed:
        try:
            lock_path.parent.chmod(0o700)
        except OSError:
            pass
    descriptor = os.open(lock_path, os.O_CREAT | os.O_RDWR, 0o600)
    handle = os.fdopen(descriptor, "a+b")
    acquired = False
    deadline = time.monotonic() + timeout if timeout is not None else None
    try:
        while True:
            try:
                _fcntl.flock(handle.fileno(), _fcntl.LOCK_EX | _fcntl.LOCK_NB)
                acquired = True
                held.add(identity)
                break
            except BlockingIOError:
                pass
            except OSError as error:
                if error.errno not in {errno.EACCES, errno.EAGAIN}:
                    raise

            now = time.monotonic()
            if not blocking or (deadline is not None and now >= deadline):
                raise LockBusyError("the requested lock is already in use")
            delay = poll_interval
            if deadline is not None:
                delay = min(delay, max(0.0, deadline - now))
            time.sleep(delay)

        yield
    finally:
        try:
            if acquired:
                held.discard(identity)
                _fcntl.flock(handle.fileno(), _fcntl.LOCK_UN)
        finally:
            handle.close()


@contextmanager
def profile_lock(
    profile_path: str | os.PathLike[str],
    *,
    lock_root: str | os.PathLike[str] | None = None,
    blocking: bool = True,
    timeout: float | None = None,
    poll_interval: float = 0.05,
) -> Iterator[None]:
    """Hold the exclusive writer lock for one browser profile.

    A same-thread nested acquisition raises ``LockReentryError``. Other owners
    either wait, time out, or fail immediately according to the supplied options.
    """

    key = profile_lock_key(profile_path)
    path = _profile_lock_path_from_digest(
        key.split(":", 1)[1], lock_root=lock_root
    )
    with _exclusive_lock(
        path,
        identity=key,
        blocking=blocking,
        timeout=timeout,
        poll_interval=poll_interval,
    ):
        yield
