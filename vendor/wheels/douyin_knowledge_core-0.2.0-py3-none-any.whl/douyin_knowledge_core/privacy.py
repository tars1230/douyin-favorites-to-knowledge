"""Conservative redaction helpers for diagnostics and user-visible errors."""

from __future__ import annotations

import re
from pathlib import Path


_TOKEN_PATTERNS = (
    re.compile(r"(?i)(?:api[_-]?key|token|secret|password)=([^\s&]+)"),
    re.compile(r"(?i)\b(?:sk|xai|hf|ghp|sf)-[A-Za-z0-9_-]{8,}\b"),
)


def _redact_tokens(value: str) -> str:
    result = value
    for pattern in _TOKEN_PATTERNS:
        if "=" in pattern.pattern:
            result = pattern.sub(lambda match: match.group(0).split("=", 1)[0] + "=<redacted>", result)
        else:
            result = pattern.sub("<redacted>", result)
    return result


def redact_path(value: str | Path, *, home: str | Path | None = None) -> str:
    """Redact user-home and absolute path components without exposing secrets."""

    raw = str(value)
    candidate = Path(raw)
    home_path = Path(home).expanduser() if home is not None else Path.home()
    try:
        if candidate.is_absolute() and candidate.is_relative_to(home_path):
            rendered = "~/" + str(candidate.relative_to(home_path))
        elif candidate.is_absolute():
            name = candidate.name
            rendered = "<absolute-path>" + (f"/{name}" if name else "")
        else:
            rendered = raw
    except (OSError, ValueError):
        rendered = "<path>"
    return _redact_tokens(rendered)
