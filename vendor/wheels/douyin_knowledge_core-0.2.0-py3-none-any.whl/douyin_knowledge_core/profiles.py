"""Versioned metadata registry for reusable browser authorization profiles."""

from __future__ import annotations

import json
import os
import platform
import re
from dataclasses import dataclass
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

from .artifacts import atomic_write_json, canonical_json, sha256_bytes
from .ids import require_identifier
from .locks import _exclusive_lock, canonical_profile_path


PROFILE_REGISTRY_SCHEMA = "douyin-knowledge-profile-registry"
PROFILE_REGISTRY_VERSION = 1
_PROFILE_ID_RE = re.compile(r"^prof1:[0-9a-f]{64}$")
_SLUG_RE = re.compile(r"^[a-z][a-z0-9_-]{0,63}$")
_RECORD_FIELDS = {
    "profile_id",
    "platform",
    "profile_path",
    "registered_at",
    "origin",
}


class ProfileRegistryError(RuntimeError):
    """Base class for registry load or validation failures."""


class ProfileRegistryCorruptError(ProfileRegistryError):
    """Raised when registry bytes do not match the exact schema."""


class ProfileRegistryVersionError(ProfileRegistryError):
    """Raised when a registry requires an unsupported migration."""


def _reject_duplicate_keys(pairs: list[tuple[str, Any]]) -> dict[str, Any]:
    value: dict[str, Any] = {}
    for key, child in pairs:
        if key in value:
            raise ProfileRegistryCorruptError(
                "profile registry contains a duplicate JSON key"
            )
        value[key] = child
    return value


def _require_slug(name: str, value: str) -> str:
    if not isinstance(value, str) or not _SLUG_RE.fullmatch(value):
        raise ValueError(f"{name} must be a lowercase slug")
    return value


def _require_timestamp(value: str) -> str:
    require_identifier("registered_at", value)
    try:
        parsed = datetime.fromisoformat(value.replace("Z", "+00:00"))
    except ValueError as error:
        raise ValueError("registered_at must be an ISO-8601 timestamp") from error
    if parsed.tzinfo is None or parsed.utcoffset() is None:
        raise ValueError("registered_at must include a UTC offset")
    return value


def make_profile_id(
    profile_path: str | os.PathLike[str], *, platform_name: str = "douyin"
) -> str:
    """Return the stable authorization-context ID for a local profile path."""

    platform_name = _require_slug("platform_name", platform_name)
    normalized = canonical_profile_path(profile_path)
    if not normalized.is_dir():
        raise ValueError("profile directory must exist before registration")
    return _make_profile_id_from_normalized(
        os.fsdecode(normalized), platform_name=platform_name
    )


def _make_profile_id_from_normalized(
    profile_path: str, *, platform_name: str
) -> str:
    payload = {"platform": platform_name, "profile_path": profile_path}
    return "prof1:" + sha256_bytes(canonical_json(payload))


def default_profile_registry_path() -> Path:
    """Return the neutral per-user registry location for the current platform."""

    home = Path.home()
    system = platform.system()
    if system == "Darwin":
        root = home / "Library" / "Application Support"
    elif system == "Windows":
        root = Path(os.environ.get("LOCALAPPDATA", home / "AppData" / "Local"))
    else:
        root = Path(os.environ.get("XDG_STATE_HOME", home / ".local" / "state"))
    return root / "douyin-knowledge-core" / "profiles.json"


@dataclass(frozen=True, slots=True)
class ProfileRecord:
    """Non-secret metadata pointing at one local authorization profile."""

    profile_id: str
    platform: str
    profile_path: str
    registered_at: str
    origin: str

    def __post_init__(self) -> None:
        if not isinstance(self.profile_id, str) or not _PROFILE_ID_RE.fullmatch(
            self.profile_id
        ):
            raise ValueError("profile_id must be a valid prof1 key")
        _require_slug("platform", self.platform)
        if not isinstance(self.profile_path, str):
            raise TypeError("profile_path must be str")
        path = Path(self.profile_path)
        if not path.is_absolute() or str(canonical_profile_path(path)) != self.profile_path:
            raise ValueError("profile_path must be normalized and absolute")
        expected_id = _make_profile_id_from_normalized(
            self.profile_path, platform_name=self.platform
        )
        if self.profile_id != expected_id:
            raise ValueError("profile_id does not match platform and profile_path")
        _require_timestamp(self.registered_at)
        _require_slug("origin", self.origin)

    def to_dict(self) -> dict[str, Any]:
        return {
            "profile_id": self.profile_id,
            "platform": self.platform,
            "profile_path": self.profile_path,
            "registered_at": self.registered_at,
            "origin": self.origin,
        }

    @classmethod
    def from_dict(cls, value: Any) -> "ProfileRecord":
        if not isinstance(value, dict) or set(value) != _RECORD_FIELDS:
            raise ProfileRegistryCorruptError(
                "profile record fields do not match the supported schema"
            )
        try:
            return cls(**value)
        except (OSError, RuntimeError, TypeError, ValueError) as error:
            raise ProfileRegistryCorruptError("profile record is invalid") from error


class ProfileRegistry:
    """Load and atomically update the neutral profile metadata registry."""

    def __init__(
        self,
        path: str | os.PathLike[str] | None = None,
        *,
        lock_timeout: float | None = 5.0,
    ) -> None:
        self.path = canonical_profile_path(path or default_profile_registry_path())
        self.lock_timeout = lock_timeout

    def load(self) -> tuple[ProfileRecord, ...]:
        if not self.path.exists():
            return ()
        try:
            raw = json.loads(
                self.path.read_text(encoding="utf-8"),
                object_pairs_hook=_reject_duplicate_keys,
            )
        except (OSError, UnicodeError, json.JSONDecodeError) as error:
            raise ProfileRegistryCorruptError("profile registry is unreadable") from error
        if not isinstance(raw, dict) or set(raw) != {
            "schema",
            "schema_version",
            "profiles",
        }:
            raise ProfileRegistryCorruptError(
                "profile registry fields do not match the supported schema"
            )
        if raw["schema"] != PROFILE_REGISTRY_SCHEMA:
            raise ProfileRegistryCorruptError("profile registry schema is invalid")
        version = raw["schema_version"]
        if not isinstance(version, int) or isinstance(version, bool):
            raise ProfileRegistryCorruptError("profile registry version is invalid")
        if version != PROFILE_REGISTRY_VERSION:
            raise ProfileRegistryVersionError(
                f"profile registry version {version} is not supported"
            )
        if not isinstance(raw["profiles"], list):
            raise ProfileRegistryCorruptError("profiles must be a list")
        records = tuple(ProfileRecord.from_dict(item) for item in raw["profiles"])
        identities = [(record.platform, record.profile_path) for record in records]
        if len(set(identities)) != len(identities):
            raise ProfileRegistryCorruptError("profile registry contains duplicate paths")
        profile_ids = [record.profile_id for record in records]
        if len(set(profile_ids)) != len(profile_ids):
            raise ProfileRegistryCorruptError("profile registry contains duplicate IDs")
        return tuple(sorted(records, key=lambda item: (item.platform, item.profile_path)))

    def register(
        self,
        profile_path: str | os.PathLike[str],
        *,
        platform_name: str = "douyin",
        origin: str,
        registered_at: str | None = None,
    ) -> ProfileRecord:
        """Register a path without reading, copying, or interpreting browser data."""

        normalized = canonical_profile_path(profile_path)
        if not normalized.is_dir():
            raise ValueError("profile directory must exist before registration")
        platform_name = _require_slug("platform_name", platform_name)
        origin = _require_slug("origin", origin)
        timestamp = registered_at or datetime.now(timezone.utc).isoformat(
            timespec="seconds"
        )
        candidate = ProfileRecord(
            profile_id=make_profile_id(normalized, platform_name=platform_name),
            platform=platform_name,
            profile_path=str(normalized),
            registered_at=timestamp,
            origin=origin,
        )

        registry_root_existed = self.path.parent.exists()
        self.path.parent.mkdir(parents=True, exist_ok=True, mode=0o700)
        if not registry_root_existed:
            try:
                self.path.parent.chmod(0o700)
            except OSError:
                pass
        lock_path = self.path.parent / ".locks" / "registry.lock"
        with _exclusive_lock(
            lock_path,
            identity=f"registry:{self.path}",
            blocking=True,
            timeout=self.lock_timeout,
            poll_interval=0.05,
        ):
            records = list(self.load())
            for record in records:
                if (
                    record.platform == candidate.platform
                    and record.profile_path == candidate.profile_path
                ):
                    return record
            records.append(candidate)
            records.sort(key=lambda item: (item.platform, item.profile_path))
            atomic_write_json(
                self.path,
                {
                    "schema": PROFILE_REGISTRY_SCHEMA,
                    "schema_version": PROFILE_REGISTRY_VERSION,
                    "profiles": [record.to_dict() for record in records],
                },
            )
        return candidate

    def register_existing_profile(
        self,
        profile_path: str | os.PathLike[str],
        *,
        platform_name: str = "douyin",
        origin: str = "legacy_favorites",
        registered_at: str | None = None,
    ) -> ProfileRecord:
        """Register an existing legacy directory by reference only."""

        return self.register(
            profile_path,
            platform_name=platform_name,
            origin=origin,
            registered_at=registered_at,
        )
