"""Deterministic content addressing and crash-safe artifact writes."""

from __future__ import annotations

import hashlib
import json
import os
import tempfile
from pathlib import Path
from typing import Any


def canonical_json(value: Any) -> bytes:
    """Return stable UTF-8 JSON bytes suitable for hashing and signatures."""

    return json.dumps(
        value,
        ensure_ascii=False,
        sort_keys=True,
        separators=(",", ":"),
        allow_nan=False,
    ).encode("utf-8")


def sha256_bytes(value: bytes | bytearray | memoryview) -> str:
    """Return the lowercase SHA-256 digest for a bytes-like value."""

    return hashlib.sha256(bytes(value)).hexdigest()


def file_sha256(path: str | os.PathLike[str]) -> str:
    """Hash a file without changing it."""

    digest = hashlib.sha256()
    with Path(path).open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def _atomic_replace(path: Path, writer: Any) -> None:
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    fd, temp_name = tempfile.mkstemp(
        prefix=f".{path.name}.", suffix=".tmp", dir=path.parent
    )
    temp_path = Path(temp_name)
    try:
        with os.fdopen(fd, "wb") as handle:
            writer(handle)
            handle.flush()
            os.fsync(handle.fileno())
        os.replace(temp_path, path)
        try:
            directory_fd = os.open(path.parent, os.O_RDONLY)
        except OSError:
            directory_fd = None
        if directory_fd is not None:
            try:
                os.fsync(directory_fd)
            finally:
                os.close(directory_fd)
    finally:
        if temp_path.exists():
            temp_path.unlink()


def atomic_write_bytes(path: str | os.PathLike[str], payload: bytes) -> None:
    """Write bytes via same-directory temp file and atomic replacement."""

    if not isinstance(payload, bytes):
        raise TypeError("payload must be bytes")
    _atomic_replace(Path(path), lambda handle: handle.write(payload))


def atomic_write_text(
    path: str | os.PathLike[str], content: str, *, encoding: str = "utf-8"
) -> None:
    """Write text atomically with an explicit encoding."""

    if not isinstance(content, str):
        raise TypeError("content must be str")
    atomic_write_bytes(path, content.encode(encoding))


def atomic_write_json(
    path: str | os.PathLike[str], payload: Any, *, indent: int = 2
) -> None:
    """Write human-readable JSON atomically without changing hash semantics."""

    encoded = (
        json.dumps(
            payload,
            ensure_ascii=False,
            sort_keys=True,
            indent=indent,
            allow_nan=False,
        )
        + "\n"
    ).encode("utf-8")
    atomic_write_bytes(path, encoded)
